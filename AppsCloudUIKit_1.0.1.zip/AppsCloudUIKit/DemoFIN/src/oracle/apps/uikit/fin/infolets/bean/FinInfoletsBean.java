package oracle.apps.uikit.fin.infolets.bean;

/*
 * Copyright (c) 2016, 2013, Oracle and/or its affiliates. All rights reserved.
 *
**/

public class FinInfoletsBean {
}//FinInfoletsBean
