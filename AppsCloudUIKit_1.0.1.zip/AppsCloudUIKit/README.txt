Copyright (c) 2016, 2013, Oracle and/or its affiliates. All rights reserved.INSTRUCTIONS while using the RDK with JDeveloper 12.1.3.0.0
(Workaround for bug 22689355)

After opening the JWS and letting JDeveloper migrate the application, you will need to manually update the WebLogic Deployment Descriptor file (weblogic.xml) in project DemoMaster.jpr to change the JSF specification-version from 2.0 to 2.1. Failure to do so will result in a build error. 

In each JPR, this file is located under the public_html/WEB-INF folder.

Change the library version reference from -

  <library-ref>
    <library-name>jsf</library-name>
    <specification-version>2.0</specification-version>
    <exact-match>true</exact-match>
  </library-ref>

- to -

  <library-ref>
    <library-name>jsf</library-name>
    <specification-version>2.1</specification-version>
    <exact-match>true</exact-match>
  </library-ref>
