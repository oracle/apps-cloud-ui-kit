package oracle.apps.ux.memoryCache;
/*
�* Copyright (c) 2017, Oracle and/or its affiliates. All rights reserved.
�*
**/
import javax.faces.context.FacesContext;
import javax.servlet.http.HttpServletRequest;

public class SessionState {
    private String _skinFamily;

    public SessionState(){
        super();
        //Set default theme
        _skinFamily = "SkyBlueTheme";
        //Check for URL parameters for themes
        HttpServletRequest request=(HttpServletRequest)FacesContext.getCurrentInstance().getExternalContext().getRequest();
        String theme = request.getParameter("theme");
        if (theme != null){
            if (theme.length() > 0){
                _skinFamily = theme;
            }//theme check
        }//null check
    }//constructor
    
    //Accessors
    public void setSkinFamily(String s) { _skinFamily = s; }
    public String getSkinFamily() { return _skinFamily; }
}//SessionState
