package oracle.apps.ux.rates.bean;
/*
�* Copyright (c) 2017, Oracle and/or its affiliates. All rights reserved.
�*
**/

public class GlobalExchangeRatesBean {
    private String _baseCurrencyCode = "USD";
    private String _baseCurrencyDesc = "United States Dollar";
    
    public GlobalExchangeRatesBean(){
        super();
    }//constructor
    
    //Accessors
    public void setBaseCurrencyCode(String s) { _baseCurrencyCode = s; }
    public String getBaseCurrencyCode() { return _baseCurrencyCode; }
    public void setBaseCurrencyDesc(String s) { _baseCurrencyDesc = s; }
    public String getBaseCurrencyDesc() { return _baseCurrencyDesc; }
}//GlobalExchangeRatesBean
