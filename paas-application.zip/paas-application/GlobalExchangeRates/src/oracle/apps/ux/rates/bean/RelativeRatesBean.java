package oracle.apps.ux.rates.bean;
/*
�* Copyright (c) 2017, Oracle and/or its affiliates. All rights reserved.
�*
**/
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import org.apache.myfaces.trinidad.model.CollectionModel;
import org.apache.myfaces.trinidad.model.ModelUtils;
import org.codehaus.jettison.json.JSONObject;

public class RelativeRatesBean {
    private Map<String, String> _countryCurrencyMap = new HashMap<String, String>();
    private String _baseCurrency = "USD";
    private String _baseCurrencyDesc = "United States Dollar";
    private String _rateDate = "";
    private String[] _colors = {"yellow", "blue", "purple", "green", "red", "orange", "gray"};
    private CollectionModel _barChartData;
    private String _dataSource = "";
    
    public RelativeRatesBean(){
        super();
        _populateCountryCurrencyMap();
    }//constructor
    
    public void populateGlobalCurrencyExchangeRates(){
        List<Hashtable> dataItems = new ArrayList<Hashtable>();
        try{
            String str = fetchCurrencyExchangeRates();
            //
            JSONObject jo = new JSONObject(str);
            setRateDate(jo.getString("date"));
            //
            JSONObject joRates = jo.getJSONObject("rates");
            int i = 0;
            Iterator<String> keys = joRates.keys();
            while (keys.hasNext()){
                String key = keys.next();
                Hashtable ht = new Hashtable();
                ht.put("series", key);
                ht.put("group", key);
                ht.put("color", getColors()[i]);
                ht.put("value", joRates.get(key));
                dataItems.add(ht);
                i++;
            }//loop
            //
            setBarChartData(ModelUtils.toCollectionModel(dataItems));
            //
        } catch(Exception e){
            e.printStackTrace();
        }//try-catch
    }//populateGlobalCurrencyExchangeRates
    
    public String fetchCurrencyExchangeRates(){
        String retunString = "";
        //
        if (getBaseCurrency().equals("USD"))
            retunString = "{\"base\":\"USD\",\"date\":\"2017-09-04\",\"rates\":{\"AUD\":1.2566,\"CAD\":1.241,\"CNY\":6.529,\"GBP\":0.77157,\"INR\":64.04,\"JPY\":109.7,\"EUR\":0.83998}}";
        else if (getBaseCurrency().equals("JPY"))
            retunString = "{\"base\":\"JPY\",\"date\":\"2017-09-04\",\"rates\":{\"AUD\":0.011455,\"CAD\":0.011312,\"CNY\":0.059516,\"GBP\":0.0070333,\"INR\":0.58377,\"USD\":0.0091156,\"EUR\":0.007657}}";
        else if (getBaseCurrency().equals("INR"))
            retunString = "{\"base\":\"INR\",\"date\":\"2017-09-04\",\"rates\":{\"AUD\":0.019622,\"CAD\":0.019378,\"CNY\":0.10195,\"GBP\":0.012048,\"JPY\":1.713,\"USD\":0.015615,\"EUR\":0.013116}}";
        else if (getBaseCurrency().equals("EUR"))
            retunString = "{\"base\":\"EUR\",\"date\":\"2017-09-04\",\"rates\":{\"AUD\":1.496,\"CAD\":1.4774,\"CNY\":7.7728,\"GBP\":0.91855,\"INR\":76.24,\"JPY\":130.6,\"USD\":1.1905}}";
        else if (getBaseCurrency().equals("CNY"))
            retunString = "{\"base\":\"CNY\",\"date\":\"2017-09-04\",\"rates\":{\"AUD\":0.19247,\"CAD\":0.19007,\"GBP\":0.11817,\"INR\":9.8086,\"JPY\":16.802,\"USD\":0.15316,\"EUR\":0.12865}}";
        else if (getBaseCurrency().equals("CAD"))
            retunString = "{\"base\":\"CAD\",\"date\":\"2017-09-04\",\"rates\":{\"AUD\":1.0126,\"CNY\":5.2611,\"GBP\":0.62173,\"INR\":51.604,\"JPY\":88.399,\"USD\":0.80581,\"EUR\":0.67686}}";
        else if (getBaseCurrency().equals("GBP"))
            retunString = "{\"base\":\"GBP\",\"date\":\"2017-09-04\",\"rates\":{\"AUD\":1.6287,\"CAD\":1.6084,\"CNY\":8.462,\"INR\":83.0,\"JPY\":142.18,\"USD\":1.2961,\"EUR\":1.0887}}";
        else if (getBaseCurrency().equals("AUD"))
            retunString = "{\"base\":\"AUD\",\"date\":\"2017-09-04\",\"rates\":{\"CAD\":0.98757,\"CNY\":5.1957,\"GBP\":0.614,\"INR\":50.963,\"JPY\":87.299,\"USD\":0.79579,\"EUR\":0.66845}}";
        //
        return retunString;
    }//fetchCurrencyExchangeRates
    
    //Accessors
    public void setCountryCurrencyMap(Map<String, String> m) { _countryCurrencyMap = m; }
    public Map<String, String> getCountryCurrencyMap() { return _countryCurrencyMap; }
    public void setBaseCurrency(String s) { _baseCurrency = s; }
    public String getBaseCurrency() { return _baseCurrency; }
    public void setBaseCurrencyDesc(String s) { _baseCurrencyDesc = s; }
    public String getBaseCurrencyDesc() { return _baseCurrencyDesc; }
    public void setRateDate(String s) { _rateDate = s; }
    public String getRateDate() { return _rateDate; }
    public void setColors(String[] a) { _colors = a; }
    public String[] getColors() { return _colors; }
    public void setBarChartData(CollectionModel cm) { _barChartData = cm; }
    public CollectionModel getBarChartData() { return _barChartData; }
    public void setDataSource(String s) { _dataSource = s; }
    public String getDataSource() {
        _dataSource = "Static currency exchange rates.";
        return _dataSource;
    }//getDataSource

    //**************************************************************************
    // Helpers
    //**************************************************************************

    private void _populateCountryCurrencyMap(){
        getCountryCurrencyMap().put("USD", "United States");
        getCountryCurrencyMap().put("CNY", "China");
        getCountryCurrencyMap().put("GBP", "United Kingdom");
        getCountryCurrencyMap().put("INR", "India");
        getCountryCurrencyMap().put("JPY", "Japan");
        getCountryCurrencyMap().put("EUR", "Europe");
        getCountryCurrencyMap().put("AUD", "Australia");
        getCountryCurrencyMap().put("CAD", "Canada");
    }//_populateCountryCurrencyMap
    
}//RelativeRatesBean
